# text-sentiment-analysis
基于TextBlob的英文文本情感分析

## 使用方法

```shell
pip install -r requirements.txt
python NLP.py
```